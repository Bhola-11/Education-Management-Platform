"""EduTrack core package."""
