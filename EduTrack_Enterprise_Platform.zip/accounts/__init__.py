"""EduTrack accounts package."""
