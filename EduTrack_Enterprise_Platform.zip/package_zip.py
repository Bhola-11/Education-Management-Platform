import os
import zipfile

zip_filename = "EduTrack_Enterprise_Platform.zip"
if os.path.exists(zip_filename):
    os.remove(zip_filename)

root_dir = os.path.abspath(".")
print(f"Creating zip archive {zip_filename} with .git and all lockfiles...")

file_count = 0
total_bytes = 0

with zipfile.ZipFile(zip_filename, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as zipf:
    for foldername, subfolders, filenames in os.walk(root_dir):
        rel_folder = os.path.relpath(foldername, root_dir)
        norm_rel = rel_folder.replace("\\", "/")
        
        if any(ignored in norm_rel for ignored in ["__pycache__", ".venv", ".pytest_cache", "staticfiles"]):
            continue
            
        for filename in filenames:
            if filename.endswith(".zip"):
                continue
            if filename.endswith(".pyc"):
                continue
            filepath = os.path.join(foldername, filename)
            arcname = os.path.relpath(filepath, root_dir)
            zipf.write(filepath, arcname)
            file_count += 1
            total_bytes += os.path.getsize(filepath)

print("Archive created successfully!")
print(f"Files archived: {file_count}")
print(f"Uncompressed size: {total_bytes / (1024*1024):.2f} MB")
print(f"Zip archive size: {os.path.getsize(zip_filename) / (1024*1024):.2f} MB")
