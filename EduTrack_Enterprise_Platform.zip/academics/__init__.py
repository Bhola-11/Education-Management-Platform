"""EduTrack academics package."""
