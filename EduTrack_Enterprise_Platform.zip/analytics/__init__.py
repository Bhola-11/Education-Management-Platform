"""EduTrack analytics package."""
