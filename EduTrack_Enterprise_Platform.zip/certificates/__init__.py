"""EduTrack certificates package."""
