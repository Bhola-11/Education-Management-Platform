"""
Class-Based Views for Attendance: Attendance Threshold Alerts
PR #40: Full CRUD Lifecycle, Filtering, Statistics, Exporting.
"""

import csv
import json
from django.views.generic import ListView, DetailView, CreateView, UpdateView, DeleteView, TemplateView, FormView
from django.urls import reverse_lazy
from django.contrib import messages
from django.http import HttpResponse, JsonResponse
from django.db import models
from attendance.models_attendance_alerts import AttendanceAlertsMaster, AttendanceAlertsConfiguration, AttendanceAlertsAuditTransaction
from attendance.forms_attendance_alerts import AttendanceAlertsMasterForm, AttendanceAlertsSearchFilterForm, AttendanceAlertsBatchActionForm
from attendance.services_attendance_alerts import AttendanceAlertsWorkflowService, AttendanceAlertsAuditReportingService

class AttendanceAlertsListView(ListView):
    """Data table view with multi-faceted filtering, sorting, and pagination."""
    model = AttendanceAlertsMaster
    template_name = "attendance/attendance_alerts_list.html"
    context_object_name = "records"
    paginate_by = 20

    def get_queryset(self):
        qs = super().get_queryset()
        q = self.request.GET.get("q")
        status = self.request.GET.get("status")
        is_active = self.request.GET.get("is_active")

        if q:
            qs = qs.filter(models.Q(code__icontains=q) | models.Q(name__icontains=q))
        if status:
            qs = qs.filter(status=status)
        if is_active in ("1", "0"):
            qs = qs.filter(is_active=(is_active == "1"))
        return qs

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        ctx["filter_form"] = AttendanceAlertsSearchFilterForm(self.request.GET)
        ctx["batch_form"] = AttendanceAlertsBatchActionForm()
        ctx["kpis"] = AttendanceAlertsWorkflowService.calculate_domain_kpis()
        return ctx

class AttendanceAlertsDetailView(DetailView):
    """In-depth profile displaying master record, details, and audit transactions."""
    model = AttendanceAlertsMaster
    template_name = "attendance/attendance_alerts_detail.html"
    context_object_name = "record"

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        ctx["transactions"] = AttendanceAlertsAuditTransaction.objects.filter(name__icontains=self.object.code)[:10]
        ctx["dossier"] = AttendanceAlertsAuditReportingService.compile_audit_dossier(self.object.pk)
        return ctx

class AttendanceAlertsCreateView(CreateView):
    """Handles controlled creation of new AttendanceAlertsMaster records."""
    model = AttendanceAlertsMaster
    form_class = AttendanceAlertsMasterForm
    template_name = "attendance/attendance_alerts_form.html"
    success_url = reverse_lazy("attendance:attendance_alerts_list")

    def form_valid(self, form):
        response = super().form_valid(form)
        messages.success(self.request, f"AttendanceAlerts '{self.object.code}' created successfully.")
        return response

class AttendanceAlertsUpdateView(UpdateView):
    """Handles updates and edits to existing AttendanceAlertsMaster records."""
    model = AttendanceAlertsMaster
    form_class = AttendanceAlertsMasterForm
    template_name = "attendance/attendance_alerts_form.html"
    success_url = reverse_lazy("attendance:attendance_alerts_list")

    def form_valid(self, form):
        response = super().form_valid(form)
        messages.success(self.request, f"AttendanceAlerts '{self.object.code}' updated successfully.")
        return response

class AttendanceAlertsDeleteView(DeleteView):
    """Handles controlled removal of AttendanceAlertsMaster records."""
    model = AttendanceAlertsMaster
    template_name = "attendance/attendance_alerts_confirm_delete.html"
    success_url = reverse_lazy("attendance:attendance_alerts_list")

    def delete(self, request, *args, **kwargs):
        obj = self.get_object()
        messages.warning(request, f"AttendanceAlerts '{obj.code}' was permanently deleted.")
        return super().delete(request, *args, **kwargs)

class AttendanceAlertsPrintView(DetailView):
    """Print-ready layout for institutional documentation and archival."""
    model = AttendanceAlertsMaster
    template_name = "attendance/attendance_alerts_print.html"
    context_object_name = "record"

class AttendanceAlertsAnalyticsView(TemplateView):
    """Domain analytics dashboard displaying metrics, histograms, and KPIs."""
    template_name = "attendance/attendance_alerts_analytics.html"

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        ctx["kpis"] = AttendanceAlertsWorkflowService.calculate_domain_kpis()
        ctx["top_records"] = AttendanceAlertsMaster.objects.filter(is_active=True).order_by("-score_rating")[:5]
        return ctx

def export_attendance_alerts_csv(request):
    """Exports filtered dataset as streaming RFC-4180 CSV document."""
    response = HttpResponse(content_type="text/csv")
    response["Content-Disposition"] = f'attachment; filename="attendance_alerts_export.csv"'
    writer = csv.writer(response)
    writer.writerow(["Code", "Name", "Status", "Capacity", "Allocated", "Monetary Value", "Effective Date", "Active"])
    
    for r in AttendanceAlertsMaster.objects.all()[:1000]:
        writer.writerow([r.code, r.name, r.status, r.capacity_limit, r.allocated_count, r.monetary_value, r.effective_date, r.is_active])
    return response

def export_attendance_alerts_json(request):
    """Exports serialized catalog entries as structured JSON payload."""
    data = [r.to_summary_dict() for r in AttendanceAlertsMaster.objects.all()[:500]]
    return JsonResponse({"catalog": data, "count": len(data)}, safe=False)
