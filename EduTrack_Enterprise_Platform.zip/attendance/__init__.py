"""EduTrack attendance package."""
