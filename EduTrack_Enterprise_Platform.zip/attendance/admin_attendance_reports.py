"""
Django Admin Configuration for Attendance: Attendance Reporting
"""

from django.contrib import admin
from attendance.models_attendance_reports import (
    AttendanceReportsMaster, AttendanceReportsConfiguration, AttendanceReportsLedger,
    AttendanceReportsAuditTransaction, AttendanceReportsScheduleMatrix, AttendanceReportsEvaluationMetric,
    AttendanceReportsRosterMapping, AttendanceReportsVerificationSignature, AttendanceReportsNotificationRule,
    AttendanceReportsAnalyticalSnapshot, AttendanceReportsComplianceLog, AttendanceReportsIntegrationBridge,
    AttendanceReportsSecurityPermit, AttendanceReportsDocumentAttachment, AttendanceReportsLifecycleTransition
)

@admin.register(AttendanceReportsMaster)
class AttendanceReportsMasterAdmin(admin.ModelAdmin):
    list_display = ("code", "name", "status", "capacity_limit", "allocated_count", "is_active", "effective_date")
    list_filter = ("status", "is_active", "effective_date")
    search_fields = ("code", "name", "description")
    readonly_fields = ("created_at", "updated_at")
    fieldsets = (
        ("Basic Identification", {"fields": ("code", "name", "slug", "description")}),
        ("Status & Weights", {"fields": ("priority", "status", "is_active", "is_verified", "is_locked")}),
        ("Quantitative Parameters", {"fields": ("score_rating", "monetary_value", "capacity_limit", "allocated_count")}),
        ("Temporal Controls", {"fields": ("effective_date", "expiration_date")}),
        ("Audit Metadata", {"fields": ("metadata", "created_at", "updated_at"), "classes": ("collapse",)}),
    )

@admin.register(AttendanceReportsConfiguration)
class AttendanceReportsConfigurationAdmin(admin.ModelAdmin):
    list_display = ("code", "name", "priority", "status", "created_at")
    search_fields = ("code", "name")

@admin.register(AttendanceReportsAuditTransaction)
class AttendanceReportsAuditTransactionAdmin(admin.ModelAdmin):
    list_display = ("code", "name", "status", "created_at")
    list_filter = ("status",)
    readonly_fields = ("created_at",)

@admin.register(AttendanceReportsLedger)
class AttendanceReportsLedgerAdmin(admin.ModelAdmin):
    list_display = ("code", "name", "monetary_value", "status")

@admin.register(AttendanceReportsScheduleMatrix)
class AttendanceReportsScheduleMatrixAdmin(admin.ModelAdmin):
    list_display = ("code", "name", "status", "effective_date")

@admin.register(AttendanceReportsEvaluationMetric)
class AttendanceReportsEvaluationMetricAdmin(admin.ModelAdmin):
    list_display = ("code", "name", "score_rating", "is_active")

@admin.register(AttendanceReportsComplianceLog)
class AttendanceReportsComplianceLogAdmin(admin.ModelAdmin):
    list_display = ("code", "name", "is_verified", "created_at")
