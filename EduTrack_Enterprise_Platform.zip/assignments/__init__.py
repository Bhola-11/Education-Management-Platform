"""EduTrack assignments package."""
